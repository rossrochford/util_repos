import json
import uuid

from bson.objectid import ObjectId
from util_shared.datetime_utils import get_utc_now


async def create_new_twitter_profiles(mongodb_cli, user_info_dicts):

    to_create = []
    for ui_dict in user_info_dicts:
        doc_id = uuid.uuid4().hex[:24]
        screen_name = ui_dict['screen_name'].lower()
        to_create.append({
            '_id': ObjectId(doc_id),
            'screen_name': screen_name,
            'user_id': ui_dict['id_str'],
            'is_available': ui_dict['is_available'],
            'user_info': json.dumps(ui_dict),
            'user_info_last_scraped': get_utc_now()
        })

    await mongodb_cli.create_many('twitter_twitterprofile', to_create)

    return {d['_id'].__str__(): d for d in to_create}
