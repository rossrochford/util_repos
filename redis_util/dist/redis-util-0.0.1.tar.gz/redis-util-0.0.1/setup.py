from setuptools import setup

# to install run: python setup.py install

setup(
    name="redis-util",
    version="0.0.01",
    author="Ross Rochford",
    author_email="rochford.ross@gmail.com",
    packages=['redis_util'],
    classifiers=[],
)
