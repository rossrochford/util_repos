import pynng

from trio_util.pynng.serialization import msgpack_decode, msgpack_encode


SEND_TIMEOUT = 6 * 1000


class PipelineReceiveDaemon(object):

    def __init__(self, address):
        self.address = address

    async def receive_loop(self):
        with pynng.Pull0() as pull_sock:
            pull_sock.listen(self.address)
            while True:
                msg = await pull_sock.arecv_msg()
                msg_bytes = msg.bytes
                if msg_bytes == b'exit':
                    print('exiting')
                    break
                await self._bytes_received(msg_bytes)

    async def _bytes_received(self, data):
        try:
            msg = msgpack_decode(data)
        except:
            print('error: failed to deserialize bytes')
            return
        await self.msg_received(msg)

    async def msg_received(self, msg):
        pass


class PipelineSendSocket(object):

    def __init__(self, address):
        self.address = address
        self.push_sock = None

    async def connect(self):
        if self.push_sock:
            return
        self.push_sock = pynng.Push0(send_timeout=SEND_TIMEOUT)
        self.push_sock.dial(self.address, block=True)

    async def send_msg(self, msg):
        try:
            data = msgpack_encode(msg)
        except:
            print(f'error: failed to serialize: {msg}')
            return
        await self._send_data(data)

    async def _send_data(self, msg):
        try:
            await self.push_sock.asend(msg)
        except pynng.exceptions.Timeout:
            print(f"PipelineSendSocket.send() to {self.address} timed-out")

    async def close(self):
        if self.push_sock:
            self.push_sock.close()
